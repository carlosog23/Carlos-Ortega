﻿# Quita la personalización Desarrollador (no toca nada más del equipo).
$destino = Join-Path $env:LOCALAPPDATA 'CarlosOrtegaDev'
Write-Host ''
Write-Host '  Quitando la personalización Desarrollador...' -ForegroundColor Yellow
$mp = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Mis proyectos'
if (Test-Path $mp) { attrib -r $mp; Remove-Item -Recurse -Force $mp -ErrorAction SilentlyContinue }
Remove-Item -Recurse -Force (Join-Path ([Environment]::GetFolderPath('Programs')) 'Carlos Ortega · Desarrollador') -ErrorAction SilentlyContinue
Remove-Item -Force (Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Themes\Carlos Ortega Desarrollador.theme') -ErrorAction SilentlyContinue
$r = Read-Host '  ¿Quitar también la pantalla de bloqueo? (pide administrador) S/N'
if ($r -match '^[sS]') {
  $cmd = "Remove-Item 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\PersonalizationCSP' -Recurse -Force -EA 0; " +
         "foreach(`$n in 'Manufacturer','SupportPhone','SupportURL','Logo'){ Remove-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation' -Name `$n -EA 0 }; " +
         "Remove-Item (Join-Path `$env:ProgramData 'CarlosOrtegaDev') -Recurse -Force -EA 0"
  try { Start-Process powershell.exe -Verb RunAs -Wait -ArgumentList "-NoProfile -Command $cmd" } catch {}
}
Start-Process "$env:SystemRoot\Resources\Themes\aero.theme"; Start-Sleep 5
Get-Process SystemSettings -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force $destino -ErrorAction SilentlyContinue
Write-Host '  Listo.' -ForegroundColor Green
Read-Host '  Presione Enter para cerrar'
