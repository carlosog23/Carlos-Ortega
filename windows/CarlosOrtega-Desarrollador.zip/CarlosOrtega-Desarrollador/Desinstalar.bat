@echo off
title Carlos Ortega - Quitar personalizacion
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0recursos\desinstalar.ps1"
