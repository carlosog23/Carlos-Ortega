﻿# Parte que necesita administrador: pantalla de bloqueo e información "Acerca de" del equipo.
param([string]$Origen)
$ErrorActionPreference = 'Continue'
$base = Join-Path $env:ProgramData 'Zona050'
New-Item -ItemType Directory -Force -Path $base | Out-Null
Copy-Item -Force (Join-Path $Origen 'fondos\Zona050-bloqueo.jpg') $base
Copy-Item -Force (Join-Path $Origen 'oem-logo.bmp') $base
$img = Join-Path $base 'Zona050-bloqueo.jpg'

# Pantalla de bloqueo
$csp = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\PersonalizationCSP'
New-Item -Path $csp -Force | Out-Null
New-ItemProperty -Path $csp -Name LockScreenImagePath   -Value $img -PropertyType String -Force | Out-Null
New-ItemProperty -Path $csp -Name LockScreenImageUrl    -Value $img -PropertyType String -Force | Out-Null
New-ItemProperty -Path $csp -Name LockScreenImageStatus -Value 1    -PropertyType DWord  -Force | Out-Null

# Configuración > Sistema > Información: muestra los datos de la zona
$oem = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation'
New-Item -Path $oem -Force | Out-Null
Set-ItemProperty -Path $oem -Name Manufacturer -Value 'Supervisión Escolar Zona 050'
Set-ItemProperty -Path $oem -Name SupportPhone -Value '616 165 5622'
Set-ItemProperty -Path $oem -Name SupportHours -Value 'Lunes a viernes'
Set-ItemProperty -Path $oem -Name SupportURL   -Value 'https://carlosog23.github.io/Carlos-Ortega/zona050/'
Set-ItemProperty -Path $oem -Name Logo         -Value (Join-Path $base 'oem-logo.bmp')
