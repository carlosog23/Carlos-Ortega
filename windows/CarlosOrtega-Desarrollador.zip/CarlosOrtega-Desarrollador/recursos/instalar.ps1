﻿# Carlos Ortega · Desarrollador — Personalizar Windows 11
# Fondos con el distintivo de autor, colores, y una carpeta «Mis proyectos» con todas las apps y herramientas.
# No borra nada del equipo: solo agrega. Para quitarlo use "Desinstalar.bat".

$ErrorActionPreference = 'Continue'
$aqui    = Split-Path -Parent $MyInvocation.MyCommand.Path
$destino = Join-Path $env:LOCALAPPDATA 'CarlosOrtegaDev'
$GH      = 'https://carlosog23.github.io/Carlos-Ortega/'

function Titulo($t) { Write-Host ''; Write-Host "  $t" -ForegroundColor Yellow }
function Bien($t)   { Write-Host "   [OK] $t" -ForegroundColor Green }
function Aviso($t)  { Write-Host "   [!]  $t" -ForegroundColor DarkYellow }

Clear-Host
Write-Host ''
Write-Host '  =====================================================' -ForegroundColor DarkBlue
Write-Host '     MAESTRO CARLOS ORTEGA  ·  Desarrollador' -ForegroundColor White
Write-Host '     Software educativo · Personalizar Windows 11' -ForegroundColor Yellow
Write-Host '  =====================================================' -ForegroundColor DarkBlue

Titulo '¿Qué fondo de pantalla quiere?'
Write-Host '   1) Código (oscuro)'
Write-Host '   2) Taller (claro)'
Write-Host '   3) Que cambie solo cada hora entre los dos'
$fondo = Read-Host '   Escriba 1, 2 o 3 y presione Enter'
if ($fondo -notin '1','2','3') { $fondo = '1' }

Titulo '¿Dónde quiere los accesos?'
Write-Host '   1) Una sola carpeta «Mis proyectos» en el escritorio y en Inicio (recomendado: no se repiten)'
Write-Host '   2) Solo en Inicio, sin tocar el escritorio'
$donde = Read-Host '   Escriba 1 o 2 y presione Enter'

# ---------- Copiar recursos ----------
Titulo 'Copiando fondos e íconos...'
New-Item -ItemType Directory -Force -Path $destino | Out-Null
Copy-Item -Recurse -Force (Join-Path $aqui 'fondos') $destino
Copy-Item -Recurse -Force (Join-Path $aqui 'iconos') $destino
Bien "Guardados en $destino"

# ---------- Tema ----------
Titulo 'Aplicando el tema Desarrollador...'
$esc = Join-Path $destino 'fondos\escritorio'
$img = @{ '1'='Desarrollador-codigo.jpg'; '2'='Desarrollador-taller.jpg'; '3'='Desarrollador-codigo.jpg' }[$fondo]
$imgRuta = Join-Path $esc $img
$modo = if ($fondo -eq '2') { 'Light' } else { 'Dark' }
$tema = @"
[Theme]
DisplayName=Carlos Ortega · Desarrollador

[Control Panel\Desktop]
Wallpaper=$imgRuta
TileWallpaper=0
WallpaperStyle=10
Pattern=

[VisualStyles]
Path=%SystemRoot%\resources\themes\Aero\Aero.msstyles
ColorStyle=NormalColor
Size=NormalSize
AutoColorization=0
ColorizationColor=0XC4F2B134
SystemMode=Dark
AppMode=$modo
VisualStyleVersion=10

[MasterThemeSelector]
MTSM=RJSPBS
"@
if ($fondo -eq '3') {
  $tema += @"

[Slideshow]
Interval=3600000
Shuffle=0
ImagesRootPath=$esc
Item0Path=$(Join-Path $esc 'Desarrollador-codigo.jpg')
Item1Path=$(Join-Path $esc 'Desarrollador-taller.jpg')
"@
}
$temas = Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Themes'
New-Item -ItemType Directory -Force -Path $temas | Out-Null
$archivoTema = Join-Path $temas 'Carlos Ortega Desarrollador.theme'
Set-Content -Path $archivoTema -Value $tema -Encoding Unicode
try {
  Start-Process -FilePath $archivoTema
  Start-Sleep -Seconds 6
  Get-Process SystemSettings -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
  Bien 'Tema aplicado (dorado del distintivo, barra de tareas oscura)'
} catch { Aviso 'No se pudo aplicar el tema solo. Ábralo en Configuración > Personalización > Temas.' }
try {
  Add-Type @'
using System.Runtime.InteropServices;
public class FondoDev { [DllImport("user32.dll", CharSet=CharSet.Auto)] public static extern int SystemParametersInfo(int a, int b, string c, int d); }
'@ -ErrorAction SilentlyContinue
  Set-ItemProperty 'HKCU:\Control Panel\Desktop' -Name WallpaperStyle -Value '10'
  if ($fondo -ne '3') { [FondoDev]::SystemParametersInfo(20, 0, $imgRuta, 3) | Out-Null }
  Bien 'Fondo de pantalla listo'
} catch { Aviso 'No se pudo poner el fondo; búsquelo en Configuración > Personalización > Fondo.' }

# ---------- Accesos ----------
Titulo 'Creando la carpeta «Mis proyectos»...'
# Se usa Chrome si está instalado (ahí están sus sesiones de las apps); si no, Edge.
$nav = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe",
         "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1

# nombre, dirección, ícono, subcarpeta, ¿ventana de app?
$items = @(
  @('Tlamatini',            "${GH}formatos-ppie/",        'tlamatini', 'Apps de la zona', $true),
  @('Tlamatini Aula',       "${GH}tlamatini-aula/",       'aula',      'Apps de la zona', $true),
  @('Aula Preescolar',      "${GH}aula-preescolar/",      'aulapre',   'Apps de la zona', $true),
  @('Aula Especial',        "${GH}aula-especial/",        'aulaesp',   'Apps de la zona', $true),
  @('El camino del saber',  "${GH}tlamatini-juego/",      'juego',     'Apps de la zona', $true),
  @('Tequio',               "${GH}tequio/",               'tequio',    'Apps de la zona', $true),
  @('Mesa Técnica',         "${GH}mesa-tecnica/",         'mesa',      'Apps de la zona', $true),
  @('Ulama',                "${GH}educacion-fisica/",     'ulama',     'Apps de la zona', $true),
  @('Página Zona 050',      "${GH}zona050/",              'zona',      'Apps de la zona', $true),
  @('Amoxcalli',            'https://claude.ai/artifact/UyeLeAp1R9fjUHM8DB1Wak', 'amoxcalli', 'Mis apps personales', $true),
  @('Ixiptla',              'https://claude.ai/artifact/GkKoD91qS8Bpt3xbXmQBRf', 'ixiptla',   'Mis apps personales', $true),
  @('Mi Fuerza',            "${GH}fuerza/",               'fuerza',    'Mis apps personales', $true),
  @('Centro de Apps',       "${GH}centro-apps/",          'centro',    '', $true),
  @('Repositorio (GitHub)', 'https://github.com/carlosog23/Carlos-Ortega', 'repo',   'Herramientas', $false),
  @('Publicaciones y servidor (GitHub Actions)', 'https://github.com/carlosog23/Carlos-Ortega/actions', 'deploy', 'Herramientas', $false),
  @('Apps Script (servidor de Tequio)', 'https://script.google.com/home', 'script', 'Herramientas', $false),
  @('Claude',               'https://claude.ai/',         'ia',        'Herramientas', $false),
  @('Google AI Studio (Gemini)', 'https://aistudio.google.com/', 'ia', 'Herramientas', $false),
  @('Google Drive',         'https://drive.google.com/',  'drive',     'Herramientas', $false)
)

$raices = @(Join-Path ([Environment]::GetFolderPath('Programs')) 'Carlos Ortega · Desarrollador')
if ($donde -ne '2') { $raices += (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Mis proyectos') }
$sh = New-Object -ComObject WScript.Shell
foreach ($raiz in $raices) {
  New-Item -ItemType Directory -Force -Path $raiz | Out-Null
  foreach ($it in $items) {
    $nombre, $url, $ico, $sub, $esApp = $it
    $carpeta = if ($sub) { Join-Path $raiz $sub } else { $raiz }
    New-Item -ItemType Directory -Force -Path $carpeta | Out-Null
    $lnk = $sh.CreateShortcut((Join-Path $carpeta "$nombre.lnk"))
    if ($nav) { $lnk.TargetPath = $nav; $lnk.Arguments = $(if ($esApp) { "--app=$url" } else { $url }) }
    else      { $lnk.TargetPath = 'explorer.exe'; $lnk.Arguments = $url }
    $lnk.IconLocation = (Join-Path $destino "iconos\$ico.ico") + ',0'
    $lnk.Description  = $nombre
    $lnk.Save()
  }
}
# Ícono del distintivo para la carpeta del escritorio
if ($donde -ne '2') {
  $mp = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Mis proyectos'
  $ini = Join-Path $mp 'desktop.ini'
  if (Test-Path $ini) { attrib -s -h $ini }
  Set-Content -Path $ini -Encoding Unicode -Value "[.ShellClassInfo]`r`nIconResource=$(Join-Path $destino 'iconos\distintivo.ico'),0`r`nInfoTip=Mis apps y herramientas de desarrollo"
  attrib +s +h $ini; attrib +r $mp
}
Bien "$($items.Count) accesos: Apps de la zona, Mis apps personales y Herramientas"

# ---------- Pantalla de bloqueo (administrador) ----------
Titulo '¿Poner también la pantalla de bloqueo con su distintivo?'
Write-Host '   Windows le pedirá permiso de administrador (elija "Sí").'
$bloq = Read-Host '   Escriba S para sí o N para no'
if ($bloq -match '^[sS]') {
  try {
    Start-Process powershell.exe -Verb RunAs -Wait -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$(Join-Path $aqui 'admin.ps1')`" -Origen `"$aqui`""
    Bien 'Pantalla de bloqueo lista'
  } catch { Aviso 'No se dio el permiso; la pantalla de bloqueo quedó como estaba.' }
}

try { Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue; Start-Sleep 2; if (-not (Get-Process explorer -ErrorAction SilentlyContinue)) { Start-Process explorer.exe } } catch {}

Write-Host ''
Write-Host '  =====================================================' -ForegroundColor DarkBlue
Write-Host '   ¡Listo! Sus apps están en la carpeta «Mis proyectos».' -ForegroundColor Green
Write-Host '   También en Inicio > «Carlos Ortega · Desarrollador».'
Write-Host '  =====================================================' -ForegroundColor DarkBlue
Read-Host '   Presione Enter para cerrar'
