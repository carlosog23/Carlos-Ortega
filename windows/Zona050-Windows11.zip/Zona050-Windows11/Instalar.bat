@echo off
title Zona Escolar 050 - Personalizar Windows 11
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0recursos\instalar.ps1"
