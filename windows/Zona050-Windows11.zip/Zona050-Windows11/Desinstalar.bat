@echo off
title Zona Escolar 050 - Quitar personalizacion
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0recursos\desinstalar.ps1"
