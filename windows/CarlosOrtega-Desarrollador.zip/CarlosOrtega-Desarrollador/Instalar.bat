@echo off
title Carlos Ortega - Desarrollador
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0recursos\instalar.ps1"
