﻿# Parte con administrador: pantalla de bloqueo e información "Acerca de" del equipo.
param([string]$Origen)
$ErrorActionPreference = 'Continue'
$base = Join-Path $env:ProgramData 'CarlosOrtegaDev'
New-Item -ItemType Directory -Force -Path $base | Out-Null
Copy-Item -Force (Join-Path $Origen 'fondos\Desarrollador-bloqueo.jpg') $base
Copy-Item -Force (Join-Path $Origen 'oem-logo.bmp') $base
$img = Join-Path $base 'Desarrollador-bloqueo.jpg'

$csp = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\PersonalizationCSP'
New-Item -Path $csp -Force | Out-Null
New-ItemProperty -Path $csp -Name LockScreenImagePath   -Value $img -PropertyType String -Force | Out-Null
New-ItemProperty -Path $csp -Name LockScreenImageUrl    -Value $img -PropertyType String -Force | Out-Null
New-ItemProperty -Path $csp -Name LockScreenImageStatus -Value 1    -PropertyType DWord  -Force | Out-Null

$oem = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation'
New-Item -Path $oem -Force | Out-Null
Set-ItemProperty -Path $oem -Name Manufacturer -Value 'Mtro. Carlos Ortega · Software educativo'
Set-ItemProperty -Path $oem -Name SupportPhone -Value '661 850 1585'
Set-ItemProperty -Path $oem -Name SupportURL   -Value 'https://carlosog23.github.io/Carlos-Ortega/centro-apps/'
Set-ItemProperty -Path $oem -Name Logo         -Value (Join-Path $base 'oem-logo.bmp')
