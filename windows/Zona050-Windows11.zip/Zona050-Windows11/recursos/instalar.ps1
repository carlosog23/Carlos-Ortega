﻿# Zona Escolar 050 · Personalizar Windows 11
# Mtro. Carlos Gabriel Ortega Gutiérrez
# Pone fondos, colores, accesos a las apps de la zona y (opcional) la pantalla de bloqueo.
# No borra nada del equipo: solo agrega. Para quitarlo use "Desinstalar.bat".

$ErrorActionPreference = 'Continue'
$aqui    = Split-Path -Parent $MyInvocation.MyCommand.Path
$destino = Join-Path $env:LOCALAPPDATA 'Zona050'
$GH      = 'https://carlosog23.github.io/Carlos-Ortega/'

function Titulo($t) { Write-Host ''; Write-Host "  $t" -ForegroundColor Cyan }
function Bien($t)   { Write-Host "   [OK] $t" -ForegroundColor Green }
function Aviso($t)  { Write-Host "   [!]  $t" -ForegroundColor Yellow }

Clear-Host
Write-Host ''
Write-Host '  =====================================================' -ForegroundColor Blue
Write-Host '     ZONA ESCOLAR 050  ·  Personalizar Windows 11' -ForegroundColor White
Write-Host '     «Responsabilidad y superación»' -ForegroundColor Yellow
Write-Host '  =====================================================' -ForegroundColor Blue

# ---------- 1. Preguntas ----------
Titulo '¿Qué computadora es esta?'
Write-Host '   1) Computadora de la zona (supervisión, dirección o escuela)'
Write-Host '   2) Mi computadora personal (agrega también Amoxcalli, Ixiptla y Mi Fuerza)'
$tipo = Read-Host '   Escriba 1 o 2 y presione Enter'
$personal = ($tipo -eq '2')

Titulo '¿Qué fondo de pantalla quiere?'
Write-Host '   1) Noche (azul con estrellas)'
Write-Host '   2) Claro (logos ISEP y Zona 050)'
Write-Host '   3) Tequio (terracota)'
Write-Host '   4) Que cambie solo cada hora entre los tres'
$fondo = Read-Host '   Escriba 1, 2, 3 o 4 y presione Enter'
if ($fondo -notin '1','2','3','4') { $fondo = '4' }

# ---------- 2. Copiar recursos ----------
Titulo 'Copiando fondos e íconos...'
New-Item -ItemType Directory -Force -Path $destino | Out-Null
Copy-Item -Recurse -Force (Join-Path $aqui 'fondos') $destino
Copy-Item -Recurse -Force (Join-Path $aqui 'iconos') $destino
Bien "Guardados en $destino"

# ---------- 3. Tema: fondo y colores ----------
Titulo 'Aplicando el tema de la Zona 050...'
$esc = Join-Path $destino 'fondos\escritorio'
$img = @{ '1'='Zona050-noche.jpg'; '2'='Zona050-claro.jpg'; '3'='Zona050-tequio.jpg'; '4'='Zona050-noche.jpg' }[$fondo]
$imgRuta = Join-Path $esc $img
$tema = @"
[Theme]
DisplayName=Zona Escolar 050

[Control Panel\Desktop]
Wallpaper=$imgRuta
TileWallpaper=0
WallpaperStyle=10
Pattern=

[VisualStyles]
Path=%SystemRoot%\resources\themes\Aero\Aero.msstyles
ColorStyle=NormalColor
Size=NormalSize
AutoColorization=0
ColorizationColor=0XC41F74C9
SystemMode=Dark
AppMode=Light
VisualStyleVersion=10

[MasterThemeSelector]
MTSM=RJSPBS
"@
if ($fondo -eq '4') {
  $tema += @"

[Slideshow]
Interval=3600000
Shuffle=0
ImagesRootPath=$esc
Item0Path=$(Join-Path $esc 'Zona050-noche.jpg')
Item1Path=$(Join-Path $esc 'Zona050-claro.jpg')
Item2Path=$(Join-Path $esc 'Zona050-tequio.jpg')
"@
}
$temas = Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Themes'
New-Item -ItemType Directory -Force -Path $temas | Out-Null
$archivoTema = Join-Path $temas 'Zona Escolar 050.theme'
Set-Content -Path $archivoTema -Value $tema -Encoding Unicode
try {
  Start-Process -FilePath $archivoTema
  Start-Sleep -Seconds 6
  Get-Process SystemSettings -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
  Bien 'Tema aplicado (azul de la zona, barra de tareas oscura)'
} catch { Aviso 'No se pudo aplicar el tema automáticamente. Ábralo en Configuración > Personalización > Temas.' }

# Fondo directo, por si el tema tardó
try {
  Add-Type @'
using System.Runtime.InteropServices;
public class Fondo { [DllImport("user32.dll", CharSet=CharSet.Auto)] public static extern int SystemParametersInfo(int a, int b, string c, int d); }
'@ -ErrorAction SilentlyContinue
  Set-ItemProperty 'HKCU:\Control Panel\Desktop' -Name WallpaperStyle -Value '10'
  Set-ItemProperty 'HKCU:\Control Panel\Desktop' -Name TileWallpaper -Value '0'
  if ($fondo -ne '4') { [Fondo]::SystemParametersInfo(20, 0, $imgRuta, 3) | Out-Null }
  Bien 'Fondo de pantalla listo'
} catch { Aviso 'No se pudo poner el fondo; búsquelo en Configuración > Personalización > Fondo.' }

# Color de acento en barras de título
try {
  Set-ItemProperty 'HKCU:\Software\Microsoft\Windows\DWM' -Name ColorPrevalence -Value 1 -Type DWord
} catch {}

# ---------- 4. Accesos a las apps ----------
Titulo 'Creando los accesos a las apps...'
$edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
$apps = @(
  @('Tlamatini',        "${GH}formatos-ppie/",   'tlamatini'),
  @('Tlamatini Aula',   "${GH}tlamatini-aula/",  'tlamatini-aula'),
  @('Tequio',           "${GH}tequio/",          'tequio'),
  @('Ulama',            "${GH}educacion-fisica/",'ulama'),
  @('Centro de Apps',   "${GH}centro-apps/",     'centro-apps'),
  @('Zona Escolar 050', "${GH}zona050/",         'zona050'),
  @('Red de apoyo',     "${GH}red-de-apoyo/",    'red-de-apoyo'),
  @('RELweb',           'https://rel.educacionbc.edu.mx/', 'relweb')
)
if ($personal) {
  $apps += @(
    @('Amoxcalli',  'https://claude.ai/artifact/UyeLeAp1R9fjUHM8DB1Wak', 'amoxcalli'),
    @('Ixiptla',    'https://claude.ai/artifact/GkKoD91qS8Bpt3xbXmQBRf', 'ixiptla'),
    @('Mi Fuerza',  "${GH}fuerza/", 'fuerza')
  )
}
$escritorio = [Environment]::GetFolderPath('Desktop')
$inicio     = Join-Path ([Environment]::GetFolderPath('Programs')) 'Zona Escolar 050'
New-Item -ItemType Directory -Force -Path $inicio | Out-Null
$sh = New-Object -ComObject WScript.Shell
$lista = @()
foreach ($a in $apps) {
  $nombre, $url, $ico = $a
  $icoRuta = Join-Path $destino "iconos\$ico.ico"
  foreach ($carpeta in @($escritorio, $inicio)) {
    $lnk = $sh.CreateShortcut((Join-Path $carpeta "$nombre.lnk"))
    if ($edge) { $lnk.TargetPath = $edge; $lnk.Arguments = "--app=$url" }
    else       { $lnk.TargetPath = 'explorer.exe'; $lnk.Arguments = $url }
    $lnk.IconLocation = "$icoRuta,0"
    $lnk.Description  = "$nombre · Zona Escolar 050"
    $lnk.Save()
  }
  $lista += $nombre
  Bien $nombre
}
Set-Content -Path (Join-Path $destino 'accesos.txt') -Value $lista -Encoding UTF8

# ---------- 5. Pantalla de bloqueo y "Acerca de" (requiere administrador) ----------
Titulo '¿Poner también la pantalla de bloqueo de la Zona 050?'
Write-Host '   Windows le pedirá permiso de administrador (aparece una ventana; elija "Sí").'
$bloq = Read-Host '   Escriba S para sí o N para no'
if ($bloq -match '^[sS]') {
  $admin = Join-Path $aqui 'admin.ps1'
  try {
    Start-Process powershell.exe -Verb RunAs -Wait -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$admin`" -Origen `"$aqui`""
    Bien 'Pantalla de bloqueo lista (se ve la próxima vez que bloquee con Windows + L)'
  } catch { Aviso 'No se dio el permiso de administrador; la pantalla de bloqueo quedó como estaba.' }
}

# ---------- 6. Refrescar el escritorio ----------
try { Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue; Start-Sleep 2; if (-not (Get-Process explorer -ErrorAction SilentlyContinue)) { Start-Process explorer.exe } } catch {}

Write-Host ''
Write-Host '  =====================================================' -ForegroundColor Blue
Write-Host '   ¡Listo! Esta computadora ya tiene la imagen de la Zona 050.' -ForegroundColor Green
Write-Host '   Las apps están en el escritorio y en Inicio > "Zona Escolar 050".'
Write-Host '   Para fijar una en la barra de tareas: clic derecho > "Anclar a la barra de tareas".'
Write-Host '  =====================================================' -ForegroundColor Blue
Read-Host '   Presione Enter para cerrar'
