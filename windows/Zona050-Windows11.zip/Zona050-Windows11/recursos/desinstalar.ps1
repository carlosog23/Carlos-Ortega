﻿# Quita los accesos y la imagen de la Zona 050 (no toca nada más del equipo).
$destino = Join-Path $env:LOCALAPPDATA 'Zona050'
Write-Host ''
Write-Host '  Quitando la personalización de la Zona 050...' -ForegroundColor Cyan
$escritorio = [Environment]::GetFolderPath('Desktop')
$lista = Join-Path $destino 'accesos.txt'
if (Test-Path $lista) { Get-Content $lista | ForEach-Object { Remove-Item (Join-Path $escritorio "$_.lnk") -ErrorAction SilentlyContinue } }
Remove-Item -Recurse -Force (Join-Path ([Environment]::GetFolderPath('Programs')) 'Zona Escolar 050') -ErrorAction SilentlyContinue
Remove-Item -Force (Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Themes\Zona Escolar 050.theme') -ErrorAction SilentlyContinue

$r = Read-Host '  ¿Quitar también la pantalla de bloqueo de la zona? (pide administrador) S/N'
if ($r -match '^[sS]') {
  $cmd = "Remove-Item 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\PersonalizationCSP' -Recurse -Force -EA 0; " +
         "foreach(`$n in 'Manufacturer','SupportPhone','SupportHours','SupportURL','Logo'){ Remove-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation' -Name `$n -EA 0 }; " +
         "Remove-Item (Join-Path `$env:ProgramData 'Zona050') -Recurse -Force -EA 0"
  try { Start-Process powershell.exe -Verb RunAs -Wait -ArgumentList "-NoProfile -Command $cmd" } catch {}
}
# Regresa el tema normal de Windows 11
Start-Process "$env:SystemRoot\Resources\Themes\aero.theme"; Start-Sleep 5
Get-Process SystemSettings -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force $destino -ErrorAction SilentlyContinue
Write-Host '  Listo. El equipo quedó como antes.' -ForegroundColor Green
Read-Host '  Presione Enter para cerrar'
